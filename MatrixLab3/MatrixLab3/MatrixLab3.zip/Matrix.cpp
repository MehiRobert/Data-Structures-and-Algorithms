#include "Matrix.h"
#include <exception>
#include <iostream>
using namespace std;


Matrix::Matrix(int nrLines, int nrCols) {
	   
	//TODO - Implementation
	this->lines = nrLines;
	this->columns = nrCols;
	this->head = -1;
	this->tail = -1;
	this->cap = 1;
	this->firstempty = 0;
	this->size = 0;

	this->elems = new DLLANode[1];
	
	
}

void Matrix::resize()
{
	this->cap = 2 * this->cap;
	DLLANode* newelems = new DLLANode[this->cap];
	for (int i = 0; i < this->size; i++)
	{
		newelems[i].data = this->elems[i].data;
		newelems[i].next = this->elems[i].next;
		newelems[i].previous = this->elems[i].previous;
	}
	delete[] this->elems;
	this->elems = newelems;
}


int Matrix::nrLines() const {
	return this->lines;
}


int Matrix::nrColumns() const {
	return this->columns;
}


TElem Matrix::element(int i, int j) const {
	if (i < 0 or j < 0 or j >= this->nrColumns() or i >= this->nrLines())
		throw exception();
	int current = this->head;
	while (current != -1)
	{
		if (this->elems[current].data->line == i and this->elems[current].data->column == j)
			return this->elems[current].data->value;
		current = this->elems[current].next;
	}
	if (current != -1 and this->elems[current].data->line == i and this->elems[current].data->column == j)
		return this->elems[current].data->value;
	return NULL_TELEM;
}

TElem Matrix::modify(int i, int j, TElem e) {

	if (i < 0 or j < 0 or j >= this->nrColumns() or i >= this->nrLines())
		throw exception();
	if (this->cap == this->size)
	{
		this->resize();
	}
	if (this->head == -1)
	{
		Triples* t = new Triples();
		t->column = j;
		t->line = i;
		t->value = e;
		this->elems[this->firstempty].data = t;
		this->elems[this->firstempty].next = -1;
		this->head = this->firstempty;
		this->tail = this->firstempty;
		this->firstempty++;
		this->size++;
		
	}
	else
	{
		int current = this->head;
		int cond = 0;
		while (current != -1 and cond == 0)
		{
			if (this->elems[current].data->line == i and this->elems[current].data->column == j)
				cond = 1;
			else
			{
				current = this->elems[current].next;
			}
		}
		// this is the add
		if (cond == 0 and e != 0)
		{
			Triples* t = new Triples();
			t->column = j;
			t->line = i;
			t->value = e;
			this->elems[this->firstempty].data = t;
			this->elems[this->firstempty].next = -1;
			this->elems[this->firstempty].previous = this->tail;
			this->elems[this->tail].next = this->firstempty;
			this->tail = this->firstempty;
			this->firstempty++;
			this->size++;
		}
		else if (cond == 1 and e!=0)
		{
			TElem old = this->elems[current].data->value;
			this->elems[current].data->value = e;
			return old;
		}
		else if (cond == 1 and e == 0)
		{
			TElem avalue = this->elems[current].data->value;
			if (current == this->head)
			{
				this->head = this->elems[current].next;
				this->elems[this->head].previous = -1;
				this->size--;
			}
			else if (this->elems[current].next == -1)
			{
				this->tail = this->elems[current].previous;
				this->elems[this->tail].next = -1;
				this->size--;
			}
			else
			{
				this->elems[this->elems[current].previous].next = this->elems[current].next;
				this->elems[this->elems[current].next].previous = this->elems[current].previous;
				this->size--;
				
				
			}
			return avalue;
		}

		
	
	}
	return 0; 
}


